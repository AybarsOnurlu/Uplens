const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../utils/i18n.js');
let content = fs.readFileSync(filePath, 'utf8');

content = content.replace(
  /errorQuota: 'API Bakiye veya Limit Hatası\. Lütfen \{\{provider\}\} hesabınızdaki bakiyeyi \(billing\) kontrol edin\.',/g,
  "errorQuota: 'Limit Hatası (429). Ücretsiz sürümde dakikada sadece 15 işlem yapılabilir. Lütfen 1 dakika bekleyip tekrar deneyin veya {{provider}} limitlerinizi kontrol edin.',"
);

content = content.replace(
  /errorQuota: 'API Quota Exceeded\. Please check your \{\{provider\}\} billing\/credits\.',/g,
  "errorQuota: 'API Quota Exceeded (429). Free tier is limited to 15 requests per minute. Please wait 1 minute and try again, or check your {{provider}} billing/limits.',"
);

fs.writeFileSync(filePath, content);
console.log('Fixed i18n quota error message');
