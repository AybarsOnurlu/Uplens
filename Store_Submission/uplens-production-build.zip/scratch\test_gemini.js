// Quick test: verify gemini-2.0-flash-lite works with user's API key
// Usage: node scratch/test_gemini.js YOUR_API_KEY

const apiKey = process.argv[2];
if (!apiKey) {
  console.log('Usage: node scratch/test_gemini.js YOUR_GEMINI_API_KEY');
  process.exit(1);
}

async function testModels() {
  console.log('--- Step 1: List available models ---');
  try {
    const listRes = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`);
    if (!listRes.ok) {
      console.error('Model list failed:', listRes.status, await listRes.text());
      return;
    }
    const listData = await listRes.json();
    const geminiModels = listData.models
      .filter(m => m.name.includes('gemini-') && m.supportedGenerationMethods?.includes('generateContent'))
      .map(m => ({ name: m.name.replace('models/', ''), methods: m.supportedGenerationMethods }));
    
    console.log(`Found ${geminiModels.length} Gemini generateContent models:`);
    geminiModels.forEach(m => console.log(`  - ${m.name}`));
    
    // Check if our defaults exist
    const hasFlashLite = geminiModels.some(m => m.name.includes('flash-lite'));
    const hasFlash = geminiModels.some(m => m.name.includes('flash') && !m.name.includes('lite'));
    console.log(`\nHas flash-lite: ${hasFlashLite}`);
    console.log(`Has flash (non-lite): ${hasFlash}`);
  } catch(e) {
    console.error('Model list error:', e.message);
  }

  console.log('\n--- Step 2: Test generateContent with gemini-2.0-flash-lite ---');
  try {
    const genRes = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-lite:generateContent?key=${apiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: 'Say "hello" and nothing else.' }] }],
        generationConfig: { temperature: 0.1 }
      })
    });
    
    console.log('Status:', genRes.status);
    const body = await genRes.json();
    
    if (genRes.ok && body.candidates?.[0]?.content?.parts?.[0]?.text) {
      console.log('SUCCESS! Response:', body.candidates[0].content.parts[0].text.trim());
    } else {
      console.error('FAILED. Response body:', JSON.stringify(body, null, 2));
    }
  } catch(e) {
    console.error('Generate error:', e.message);
  }

  console.log('\n--- Step 3: Test with gemini-2.0-flash (non-lite) ---');
  try {
    const genRes = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: 'Say "hello" and nothing else.' }] }],
        generationConfig: { temperature: 0.1 }
      })
    });
    
    console.log('Status:', genRes.status);
    const body = await genRes.json();
    
    if (genRes.ok && body.candidates?.[0]?.content?.parts?.[0]?.text) {
      console.log('SUCCESS! Response:', body.candidates[0].content.parts[0].text.trim());
    } else {
      console.error('FAILED. Response body:', JSON.stringify(body, null, 2));
    }
  } catch(e) {
    console.error('Generate error:', e.message);
  }
}

testModels();
