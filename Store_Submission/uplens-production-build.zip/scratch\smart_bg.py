﻿from PIL import Image

def make_transparent_luminance(input_path, output_path):
    img = Image.open(input_path).convert('RGBA')
    pixels = img.load()
    width, height = img.size
    
    bg_threshold = 40
    
    for y in range(height):
        for x in range(width):
            r, g, b, a = pixels[x, y]
            
            # Use max RGB channel as brightness
            brightness = max(r, g, b)
            
            if brightness <= bg_threshold:
                alpha = 0
            else:
                # Map brightness from (bg_threshold..255) to (0..255)
                alpha = int(((brightness - bg_threshold) / (255 - bg_threshold)) * 255)
                
                # Boost the RGB values to compensate for premultiplied alpha appearance if needed, 
                # but standard alpha blending should look great.
                
            pixels[x, y] = (r, g, b, alpha)
            
    img.save(output_path)
    print(f'Saved {output_path}')

make_transparent_luminance('assets/uplens_logo_final.png', 'assets/uplens_logo_transparent.png')
