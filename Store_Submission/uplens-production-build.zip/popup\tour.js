import { StorageHelper } from '../utils/storage.js';
import { t } from '../utils/i18n.js';

export async function initTour() {
  const settings = await StorageHelper.getSettings();
  if (settings.hasSeenTour) return;

  // Start Tour
  const tour = new OnboardingTour();
  tour.start();
}

class OnboardingTour {
  constructor() {
    this.steps = [
      {
        isLanguageSelect: true
      },
      {
        target: 'footer',
        tab: 'panel-settings',
        text: () => t('ui.tourStepPrivacy')
      },
      {
        target: '#api-key',
        tab: 'panel-settings',
        text: () => t('ui.tourStep1')
      },
      {
        target: '#cv-text',
        tab: 'panel-settings',
        text: () => t('ui.tourStep2')
      },
      {
        target: '[data-tab="panel-analysis"]',
        tab: 'panel-analysis',
        text: () => t('ui.tourStep3')
      }
    ];
    this.currentStep = 0;
    this.overlay = null;
    this.tooltip = null;
    this.activeTarget = null;
    this.originalStyles = new Map();
  }

  start() {
    this.createOverlay();
    this.createTooltip();
    this.showStep();
  }

  createOverlay() {
    this.overlay = document.createElement('div');
    this.overlay.className = 'fixed inset-0 bg-black/70 z-[100] transition-opacity duration-300';
    document.body.appendChild(this.overlay);
  }

  createTooltip() {
    this.tooltip = document.createElement('div');
    this.tooltip.className = 'absolute z-[101] w-64 border rounded-xl p-4 shadow-2xl opacity-0 transition-opacity duration-300 pointer-events-auto';
    
    this.tooltip.innerHTML = `
      <p id="tour-text" class="text-sm mb-4 font-medium leading-relaxed"></p>
      <div class="flex justify-between items-center">
        <button id="tour-skip" class="text-xs hover:opacity-75 font-medium transition-opacity"></button>
        <div class="flex items-center gap-2">
          <span id="tour-indicator" class="text-[10px] font-bold"></span>
          <button id="tour-next" class="px-3 py-1.5 bg-green-500 hover:bg-green-600 text-white text-xs font-bold rounded-lg transition-colors"></button>
        </div>
      </div>
    `;
    
    document.body.appendChild(this.tooltip);

    document.getElementById('tour-skip').addEventListener('click', () => this.end());
    document.getElementById('tour-next').addEventListener('click', () => {
      this.currentStep++;
      if (this.currentStep >= this.steps.length) {
        this.end();
      } else {
        this.showStep();
      }
    });
  }

  showStep() {
    this.clearHighlight();
    const step = this.steps[this.currentStep];

    if (step.isLanguageSelect) {
      this.showLanguageSelect();
      return;
    }

    // Switch tab
    const tabBtn = document.querySelector(`[data-tab="${step.tab}"]`);
    if (tabBtn) tabBtn.click();

    setTimeout(() => {
      const targetEl = document.querySelector(step.target);
      if (!targetEl) {
        this.end();
        return;
      }

      this.highlight(targetEl);
      
      // Dynamic Theme Styles (Inline to bypass Tailwind purge issues)
      const isDark = document.body.classList.contains('dark');
      this.tooltip.style.backgroundColor = isDark ? '#1e293b' : '#ffffff';
      this.tooltip.style.borderColor = isDark ? '#475569' : '#e2e8f0';
      document.getElementById('tour-text').style.color = isDark ? '#e2e8f0' : '#1e293b';
      document.getElementById('tour-skip').style.color = isDark ? '#94a3b8' : '#64748b';
      document.getElementById('tour-indicator').style.color = isDark ? '#64748b' : '#94a3b8';

      // Update Tooltip content
      document.getElementById('tour-text').textContent = step.text();
      document.getElementById('tour-skip').textContent = t('ui.tourSkip');
      document.getElementById('tour-indicator').textContent = `${this.currentStep + 1} / ${this.steps.length}`;
      document.getElementById('tour-next').textContent = this.currentStep === this.steps.length - 1 ? t('ui.tourFinish') : t('ui.tourNext');

      this.positionTooltip(targetEl);
      this.tooltip.classList.remove('opacity-0');
      this.tooltip.classList.add('opacity-100');
    }, 50); // Wait for tab switch
  }

  showLanguageSelect() {
    this.tooltip.classList.add('opacity-0');
    
    const isDark = document.body.classList.contains('dark');
    const box = document.createElement('div');
    box.id = 'tour-lang-box';
    box.className = 'absolute z-[101] border rounded-xl p-6 shadow-2xl flex flex-col items-center justify-center gap-4 pointer-events-auto';
    box.style.top = '50%';
    box.style.left = '50%';
    box.style.transform = 'translate(-50%, -50%)';
    box.style.width = '320px';
    box.style.backgroundColor = isDark ? '#1e293b' : '#ffffff';
    box.style.borderColor = isDark ? '#475569' : '#e2e8f0';

    box.innerHTML = `
      <h2 class="text-lg font-bold text-center" style="color: ${isDark ? '#ffffff' : '#1e293b'}">${t('ui.tourWelcome') || 'Welcome to UpLens!'}</h2>
      <p class="text-sm text-center mb-2" style="color: ${isDark ? '#cbd5e1' : '#475569'}">${t('ui.tourLangSelect') || 'Please select your language:'}</p>
      <select id="tour-lang-select" class="w-full border rounded-lg p-3 text-sm focus:border-blue-500 focus:outline-none mb-2" style="background-color: ${isDark ? '#0f172a' : '#f8fafc'}; border-color: ${isDark ? '#334155' : '#e2e8f0'}; color: ${isDark ? '#ffffff' : '#1e293b'}">
        <option value="en">English (EN)</option>
        <option value="tr">Türkçe (TR)</option>
        <option value="de">Deutsch (DE)</option>
        <option value="fr">Français (FR)</option>
        <option value="es">Español (ES)</option>
        <option value="pt">Português (PT)</option>
        <option value="ar">العربية (SA)</option>
      </select>
      <button id="tour-lang-start" class="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold rounded-lg transition-colors mt-2 flex justify-center items-center">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
      </button>
    `;
    
    document.body.appendChild(box);

    document.getElementById('tour-lang-start').addEventListener('click', async () => {
      const selectedLang = document.getElementById('tour-lang-select').value;
      const settings = await StorageHelper.getSettings();
      await StorageHelper.saveSettings({ ...settings, language: selectedLang });
      
      // Dispatch event to popup.js to update UI and apply language
      window.dispatchEvent(new CustomEvent('languageChanged', { detail: selectedLang }));
      
      // Clean up box and move to next step
      box.remove();
      this.currentStep++;
      this.showStep();
    });
  }

  highlight(el) {
    this.activeTarget = el;
    
    // Scroll into view if needed
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });

    // Store original styles that we might change
    this.originalStyles.set(el, {
      position: el.style.position,
      zIndex: el.style.zIndex,
      backgroundColor: el.style.backgroundColor,
      boxShadow: el.style.boxShadow,
      outline: el.style.outline,
      outlineOffset: el.style.outlineOffset,
      borderRadius: el.style.borderRadius
    });

    // Make element pop over overlay
    const computedStyle = window.getComputedStyle(el);
    if (computedStyle.position === 'static') {
      el.style.position = 'relative';
    }
    el.style.zIndex = '102';
    
    // Add distinct glowing border to highlight the target
    el.style.outline = '3px solid #10b981'; // emerald-500
    el.style.outlineOffset = '4px';
    el.style.boxShadow = '0 0 25px rgba(16, 185, 129, 0.4)';
    el.style.borderRadius = computedStyle.borderRadius !== '0px' ? computedStyle.borderRadius : '8px';
    
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
      el.style.backgroundColor = document.body.classList.contains('dark') ? '#1e293b' : '#f8fafc'; // slate-800 or slate-50
    } else {
      el.style.backgroundColor = computedStyle.backgroundColor !== 'rgba(0, 0, 0, 0)' ? computedStyle.backgroundColor : (document.body.classList.contains('dark') ? '#0f172a' : '#ffffff');
    }
  }

  clearHighlight() {
    if (this.activeTarget && this.originalStyles.has(this.activeTarget)) {
      const orig = this.originalStyles.get(this.activeTarget);
      this.activeTarget.style.position = orig.position;
      this.activeTarget.style.zIndex = orig.zIndex;
      this.activeTarget.style.backgroundColor = orig.backgroundColor;
      this.activeTarget.style.boxShadow = orig.boxShadow;
      this.activeTarget.style.outline = orig.outline;
      this.activeTarget.style.outlineOffset = orig.outlineOffset;
      this.activeTarget.style.borderRadius = orig.borderRadius;
      this.activeTarget = null;
    }
    this.tooltip.classList.remove('opacity-100');
    this.tooltip.classList.add('opacity-0');
  }

  positionTooltip(targetEl) {
    // Need a tiny delay to ensure element is in viewport after scrollIntoView
    setTimeout(() => {
      const rect = targetEl.getBoundingClientRect();
      const tooltipRect = this.tooltip.getBoundingClientRect();
      
      let top = rect.bottom + 10;
      let left = rect.left;

      // If tooltip goes below window, put it above target
      if (top + tooltipRect.height > window.innerHeight) {
        top = rect.top - tooltipRect.height - 10;
      }
      
      // If it goes above window (very rare), adjust
      if (top < 0) {
        top = 10;
      }

      // If tooltip goes off right edge
      if (left + tooltipRect.width > window.innerWidth) {
        left = window.innerWidth - tooltipRect.width - 10;
      }

      this.tooltip.style.top = `${top}px`;
      this.tooltip.style.left = `${left}px`;
    }, 100);
  }

  async end() {
    this.clearHighlight();
    if (this.overlay) this.overlay.remove();
    if (this.tooltip) this.tooltip.remove();
    
    const settings = await StorageHelper.getSettings();
    await StorageHelper.saveSettings({ ...settings, hasSeenTour: true });
  }
}
