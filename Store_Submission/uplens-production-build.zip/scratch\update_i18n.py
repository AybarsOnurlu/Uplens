﻿import re

with open('utils/i18n.js', 'r', encoding='utf-8') as f:
    content = f.read()

# Add translations to Turkish
content = re.sub(
    r"(tr: \{\s*api: \{.*?\},\s*ui: \{)",
    r"\1\n      apiTrustMsg: '🔒 Anahtarınız sadece tarayıcınızda (lokal) saklanır. Kodlarımızı <a href=\"https://github.com/AybarsOnurlu/Uplens\" target=\"_blank\" class=\"underline text-emerald-400 hover:text-emerald-300\">GitHub</a> üzerinden inceleyebilirsiniz.',\n      tourStepPrivacy: 'UpLens %100 Açık Kaynaklıdır ve API anahtarınızı asla sunucularında saklamaz. Tüm kodlarımızı GitHub üzerinden şeffafça inceleyebilirsiniz.',",
    content,
    flags=re.DOTALL
)

# Add translations to English and other languages
languages = ['en', 'de', 'fr', 'es', 'pt', 'ar']
for lang in languages:
    content = re.sub(
        rf"({lang}: \{{\s*api: \{{\.*?\}}.*?,\s*ui: \{{)",
        rf"\1\n      apiTrustMsg: '🔒 Your key is stored locally in your browser. View our open-source code on <a href=\"https://github.com/AybarsOnurlu/Uplens\" target=\"_blank\" class=\"underline text-emerald-400 hover:text-emerald-300\">GitHub</a>.',\n      tourStepPrivacy: 'UpLens is 100% Open Source and never stores your API key on servers. You can transparently review all our code on GitHub.',",
        content,
        flags=re.DOTALL
    )

with open('utils/i18n.js', 'w', encoding='utf-8') as f:
    f.write(content)

print('Updated i18n.js')
