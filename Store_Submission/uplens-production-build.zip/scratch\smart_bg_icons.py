﻿from PIL import Image
import os

def make_transparent_luminance(input_path, output_path):
    if not os.path.exists(input_path):
        print(f"Skipping {input_path}, file not found")
        return
        
    img = Image.open(input_path).convert('RGBA')
    pixels = img.load()
    width, height = img.size
    
    bg_threshold = 40
    
    for y in range(height):
        for x in range(width):
            r, g, b, a = pixels[x, y]
            brightness = max(r, g, b)
            
            if brightness <= bg_threshold:
                alpha = 0
            else:
                alpha = int(((brightness - bg_threshold) / (255 - bg_threshold)) * 255)
                
            pixels[x, y] = (r, g, b, alpha)
            
    img.save(output_path)
    print(f'Processed {output_path}')

# Re-process all icon files
make_transparent_luminance('icons/icon-16.png', 'icons/icon-16.png')
make_transparent_luminance('icons/icon-32.png', 'icons/icon-32.png')
make_transparent_luminance('icons/icon-48.png', 'icons/icon-48.png')
make_transparent_luminance('icons/icon-128.png', 'icons/icon-128.png')
make_transparent_luminance('Store_Submission/store_icon.png', 'Store_Submission/store_icon.png')
