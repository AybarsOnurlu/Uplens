﻿const fs = require('fs');
let content = fs.readFileSync('utils/i18n.js', 'utf8');

const apiTrustMsgEn = "'🔒 Your key is stored locally in your browser. View our open-source code on <a href=\"https://github.com/AybarsOnurlu/Uplens\" target=\"_blank\" class=\"underline text-emerald-400 hover:text-emerald-300\">GitHub</a>.'";
const tourStepPrivacyEn = "'UpLens is 100% Open Source and never stores your API key on servers. You can transparently review all our code on GitHub.'";

const languages = ['en', 'de', 'fr', 'es', 'pt', 'ar'];

for (const lang of languages) {
    const regex = new RegExp(`(${lang}:\\s*\\{[\\s\\S]*?ui:\\s*\\{)`);
    content = content.replace(regex, `$1\n      apiTrustMsg: ${apiTrustMsgEn},\n      tourStepPrivacy: ${tourStepPrivacyEn},`);
}

fs.writeFileSync('utils/i18n.js', content, 'utf8');
console.log('Fixed i18n.js');
