﻿import fs from 'fs';

let content = fs.readFileSync('utils/i18n.js', 'utf8');

content = content.replace(/skillMatchPercent: '%{{percent}} Uyum',/g, "addSkillsWarning: 'Ayarlardan becerilerinizi ekleyin',\n      noJobSkills: 'İlanda yetenek etiketi bulunamadı',\n      skillMatchPercent: '%{{percent}} Uyum',");
content = content.replace(/skillMatchPercent: '{{percent}}% Match',/g, "addSkillsWarning: 'Add your skills in settings',\n      noJobSkills: 'No skill tags found on this job',\n      skillMatchPercent: '{{percent}}% Match',");
content = content.replace(/skillMatchPercent: '{{percent}}% Übereinstimmung',/g, "addSkillsWarning: 'Fügen Sie Ihre Fähigkeiten in den Einstellungen hinzu',\n      noJobSkills: 'Keine Fähigkeiten-Tags in diesem Job gefunden',\n      skillMatchPercent: '{{percent}}% Übereinstimmung',");
content = content.replace(/skillMatchPercent: '{{percent}}% de correspondance',/g, "addSkillsWarning: 'Ajoutez vos compétences dans les paramètres',\n      noJobSkills: 'Aucune balise de compétence trouvée sur ce poste',\n      skillMatchPercent: '{{percent}}% de correspondance',");
content = content.replace(/skillMatchPercent: '{{percent}}% de coincidencia',/g, "addSkillsWarning: 'Agregue sus habilidades en la configuración',\n      noJobSkills: 'No se encontraron etiquetas de habilidades en este trabajo',\n      skillMatchPercent: '{{percent}}% de coincidencia',");
content = content.replace(/skillMatchPercent: '{{percent}}% de correspondência',/g, "addSkillsWarning: 'Adicione suas habilidades nas configurações',\n      noJobSkills: 'Nenhuma tag de habilidade encontrada neste trabalho',\n      skillMatchPercent: '{{percent}}% de correspondência',");
content = content.replace(/skillMatchPercent: '{{percent}}% تطابق',/g, "addSkillsWarning: 'أضف مهاراتك في الإعدادات',\n      noJobSkills: 'لم يتم العثور على علامات مهارة في هذه الوظيفة',\n      skillMatchPercent: '{{percent}}% تطابق',");

fs.writeFileSync('utils/i18n.js', content, 'utf8');
