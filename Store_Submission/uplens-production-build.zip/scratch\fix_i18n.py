﻿import re

with open('utils/i18n.js', 'r', encoding='utf-8') as f:
    content = f.read()

apiTrustMsgEn = "'🔒 Your key is stored locally in your browser. View our open-source code on <a href=\"https://github.com/AybarsOnurlu/Uplens\" target=\"_blank\" class=\"underline text-emerald-400 hover:text-emerald-300\">GitHub</a>.'"
tourStepPrivacyEn = "'UpLens is 100% Open Source and never stores your API key on servers. You can transparently review all our code on GitHub.'"

languages = ['en', 'de', 'fr', 'es', 'pt', 'ar']

for lang in languages:
    content = re.sub(
        rf"({lang}:\s*\{{[\s\S]*?ui:\s*\{{)",
        rf"\1\n      apiTrustMsg: {apiTrustMsgEn},\n      tourStepPrivacy: {tourStepPrivacyEn},",
        content
    )

with open('utils/i18n.js', 'w', encoding='utf-8') as f:
    f.write(content)

print('Fixed i18n.js')
