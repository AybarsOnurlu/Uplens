﻿from PIL import Image

def check_bg(filename):
    try:
        img = Image.open(filename).convert('RGBA')
        pixels = img.load()
        print(f'{filename} Top-Left:', pixels[0, 0])
    except Exception as e:
        print(f'Error reading {filename}: {e}')

check_bg('icons/icon-48.png')
check_bg('icons/icon-128.png')
