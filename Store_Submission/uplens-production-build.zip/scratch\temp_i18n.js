const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../utils/i18n.js');
let content = fs.readFileSync(filePath, 'utf8');

// Replace OpenAI with {{provider}} in errorQuota
content = content.replace(/Lütfen OpenAI hesabınızdaki/g, 'Lütfen {{provider}} hesabınızdaki');
content = content.replace(/your OpenAI billing/g, 'your {{provider}} billing');
content = content.replace(/OpenAI-Guthaben/g, '{{provider}}-Guthaben');
content = content.replace(/solde OpenAI/g, 'solde {{provider}}');
content = content.replace(/saldo\/créditos de OpenAI/g, 'saldo/créditos de {{provider}}');
content = content.replace(/saldo da OpenAI/g, 'saldo da {{provider}}');
content = content.replace(/رصيد OpenAI/g, 'رصيد {{provider}}');

// Add provider context to Auth Error
content = content.replace(/API Yetkilendirme hatası\./g, 'API Yetkilendirme hatası ({{provider}}).');
content = content.replace(/API Auth error\./g, 'API Auth error ({{provider}}).');

fs.writeFileSync(filePath, content);
console.log('Fixed i18n.js');
