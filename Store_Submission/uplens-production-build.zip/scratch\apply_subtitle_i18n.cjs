﻿const fs = require('fs');
let content = fs.readFileSync('utils/i18n.js', 'utf8');

content = content.replace(/tourSkip: 'Atla',/g, "appSubtitle: 'Upwork ilanlarını akıllıca analiz edin',\n      tourSkip: 'Atla',");
content = content.replace(/tourSkip: 'Skip',/g, "appSubtitle: 'Analyze Upwork job postings smartly',\n      tourSkip: 'Skip',");
content = content.replace(/tourSkip: 'Überspringen',/g, "appSubtitle: 'Upwork-Stellenangebote intelligent analysieren',\n      tourSkip: 'Überspringen',");
content = content.replace(/tourSkip: 'Passer',/g, "appSubtitle: 'Analysez intelligemment les offres Upwork',\n      tourSkip: 'Passer',");
content = content.replace(/tourSkip: 'Saltar',/g, "appSubtitle: 'Analiza inteligentemente las ofertas de Upwork',\n      tourSkip: 'Saltar',");
content = content.replace(/tourSkip: 'Pular',/g, "appSubtitle: 'Analise vagas do Upwork de forma inteligente',\n      tourSkip: 'Pular',");
content = content.replace(/tourSkip: 'تخطي',/g, "appSubtitle: 'تحليل وظائف Upwork بذكاء',\n      tourSkip: 'تخطي',");

fs.writeFileSync('utils/i18n.js', content, 'utf8');
