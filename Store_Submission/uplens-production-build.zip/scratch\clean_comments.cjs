﻿const fs = require('fs');
const path = require('path');

function walkDir(dir) {
    let files = [];
    const list = fs.readdirSync(dir);
    list.forEach(file => {
        const fullPath = path.join(dir, file);
        const stat = fs.statSync(fullPath);
        if (stat && stat.isDirectory()) {
            if (!fullPath.includes('node_modules') && !fullPath.includes('.git') && !fullPath.includes('Store_Submission') && !fullPath.includes('scratch') && !fullPath.includes('tests')) {
                files = files.concat(walkDir(fullPath));
            }
        } else {
            if (fullPath.endsWith('.js') || fullPath.endsWith('.css') || fullPath.endsWith('.html')) {
                files.push(fullPath);
            }
        }
    });
    return files;
}

const files = walkDir('.');

files.forEach(file => {
    let content = fs.readFileSync(file, 'utf8');
    const lines = content.split(/\r?\n/);
    const newLines = lines.filter(line => !line.trim().startsWith('// ─'));
    const newContent = newLines.join('\n').replace(/\n{3,}/g, '\n\n');
    
    if (newLines.length !== lines.length) {
        fs.writeFileSync(file, newContent, 'utf8');
        console.log('Cleaned:', file);
    }
});
