import fs from 'fs';

let content = fs.readFileSync('utils/i18n.js', 'utf8');

const translations = {
  en: {
    addSkillsWarning: 'Add your skills in settings',
    noJobSkills: 'No skill tags found on this job'
  },
  tr: {
    addSkillsWarning: 'Ayarlardan becerilerinizi ekleyin',
    noJobSkills: '�landa yetenek etiketi bulunamad�'
  },
  de: {
    addSkillsWarning: 'F�gen Sie Ihre F�higkeiten in den Einstellungen hinzu',
    noJobSkills: 'Keine F�higkeiten-Tags in diesem Job gefunden'
  },
  fr: {
    addSkillsWarning: 'Ajoutez vos comp�tences dans les param�tres',
    noJobSkills: 'Aucune balise de comp�tence trouv�e sur ce poste'
  },
  es: {
    addSkillsWarning: 'Agregue sus habilidades en la configuraci�n',
    noJobSkills: 'No se encontraron etiquetas de habilidades en este trabajo'
  },
  pt: {
    addSkillsWarning: 'Adicione suas habilidades nas configura��es',
    noJobSkills: 'Nenhuma tag de habilidade encontrada neste trabalho'
  },
  ar: {
    addSkillsWarning: '??? ??????? ?? ?????????',
    noJobSkills: '?? ??? ?????? ??? ?????? ????? ?? ??? ???????'
  }
};

const langs = ['en', 'tr', 'de', 'fr', 'es', 'pt', 'ar'];

for (const lang of langs) {
  const trans = translations[lang];
  const replaceStr = `skillMatchPercent:`;
  const insertStr = `addSkillsWarning: '${trans.addSkillsWarning}',\n      noJobSkills: '${trans.noJobSkills}',\n      skillMatchPercent:`;
  
  // Find where skillMatchPercent is for this lang, but we must do it sequentially or use regex carefully
  content = content.replace(new RegExp(`(skillMatchPercent:)`, 'g'), (match, p1, offset, string) => {
    // Only replace the one that belongs to the current lang? 
    // Wait, replacing all globally is wrong if I do it in a loop.
    return match;
  });
}
