﻿import { LANGUAGES, t } from "../utils/i18n.js";
// t uses currentLanguage which is internal to i18n.js, we can't change it easily unless we call setLanguage() or something if it exists
import fs from "fs";
const file = fs.readFileSync("../utils/i18n.js", "utf8");
// Let's just manually test if tr has the key
console.log(file.includes("apiTrustMsg: '🔒 Anahtarınız"));
