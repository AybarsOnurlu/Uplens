const apiKey = process.argv[2];
async function testBad() {
  const genRes = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/Gemini 3.1 Pro (High):generateContent?key=${apiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: 'hello' }] }]
      })
  });
  console.log('Status:', genRes.status);
  console.log('Body:', await genRes.text());
}
testBad();
