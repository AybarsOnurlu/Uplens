﻿from PIL import Image
import math

def remove_bg(filename, out_filename):
    img = Image.open(filename).convert('RGBA')
    width, height = img.size
    pixels = img.load()
    
    bg_color = (12, 16, 25)
    
    for y in range(height):
        for x in range(width):
            r, g, b, a = pixels[x, y]
            
            dist = math.sqrt((r - bg_color[0])**2 + (g - bg_color[1])**2 + (b - bg_color[2])**2)
            
            if dist < 45:
                # Non-linear alpha mapping for smoother edges
                alpha = int((dist / 45) ** 2 * 255)
                pixels[x, y] = (r, g, b, alpha)

    img.save(out_filename)
    print(f'Processed {filename} -> {out_filename}')

remove_bg('assets/uplens_logo_final.png', 'assets/uplens_logo_final.png')
remove_bg('icons/icon-16.png', 'icons/icon-16.png')
remove_bg('icons/icon-32.png', 'icons/icon-32.png')
remove_bg('icons/icon-48.png', 'icons/icon-48.png')
remove_bg('icons/icon-128.png', 'icons/icon-128.png')
