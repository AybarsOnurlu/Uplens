﻿from PIL import Image

# Open the image
img = Image.open('assets/uplens_logo_final.png').convert('RGBA')
pixels = img.load()

# Print corners to see the background color
print('Top-Left:', pixels[0, 0])
print('Top-Right:', pixels[img.width-1, 0])
print('Bottom-Left:', pixels[0, img.height-1])
print('Bottom-Right:', pixels[img.width-1, img.height-1])
