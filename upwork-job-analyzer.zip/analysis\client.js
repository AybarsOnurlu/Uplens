/**
 * Client Analysis Module — Müşteri Analizi
 * 
 * Müşterinin güvenilirliğini ödeme doğrulama, harcama geçmişi,
 * işe alım oranı, puan ve değerlendirme sayısı gibi faktörlere göre puanlar.
 */


/**
 * Müşteri verilerini analiz eder ve güvenilirlik skoru üretir
 * 
 * Puanlama sistemi:
 * - Baz skor: 50 (nötr başlangıç)
 * - Ödeme doğrulama: +20 / 0
 * - Toplam harcama: -20 ile +20 arası
 * - İşe alım oranı: -30 ile +20 arası
 * - Puan: -20 ile +20 arası
 * - Değerlendirme sayısı: -10 ile +15 arası
 * 
 * @param {object} jobData - İçerik scriptinden gelen iş verisi
 * @returns {{ score: number, label: string, details: string[] }}
 */
export function analyzeClient(jobData) {
  const details = [];
  let score = 50; // Nötr başlangıç

  const client = jobData.client;

  // ─── Müşteri verisi yoksa ────────────────────────────────────
  if (!client) {
    details.push('⚠️ Müşteri bilgisi bulunamadı');
    return {
      score: 30,
      label: scoreToLabel(30),
      details
    };
  }

  // ═══════════════════════════════════════════════════════════════
  // 1. ÖDEME DOĞRULAMA (+20 / 0)
  // ═══════════════════════════════════════════════════════════════
  if (client.paymentVerified === true) {
    score += 20;
    details.push('✅ Ödeme yöntemi doğrulanmış (+20)');
  } else if (client.paymentVerified === false) {
    // Doğrulanmamış — puan eklemiyoruz, ama uyarı veriyoruz
    details.push('⚠️ Ödeme yöntemi doğrulanmamış (0)');
  }

  // ═══════════════════════════════════════════════════════════════
  // 2. TOPLAM HARCAMA (-20 ile +20)
  // ═══════════════════════════════════════════════════════════════
  const totalSpent = client.totalSpentNumeric;

  if (totalSpent !== null && totalSpent !== undefined) {
    if (totalSpent === 0) {
      score -= 20;
      details.push('🚩 Toplam harcama: $0 — Yeni müşteri (-20)');
    } else if (totalSpent < 1000) {
      score -= 10;
      details.push(`📉 Toplam harcama: $${formatMoney(totalSpent)} — Düşük (-10)`);
    } else if (totalSpent >= 1000 && totalSpent < 10000) {
      score += 10;
      details.push(`👍 Toplam harcama: $${formatMoney(totalSpent)} — Orta (+10)`);
    } else if (totalSpent >= 10000) {
      score += 20;
      details.push(`🌟 Toplam harcama: $${formatMoney(totalSpent)} — Yüksek (+20)`);
    }
  } else {
    details.push('⚠️ Toplam harcama bilgisi yok');
  }

  // ═══════════════════════════════════════════════════════════════
  // 3. İŞE ALIM ORANI (-30 ile +20)
  // ═══════════════════════════════════════════════════════════════
  const hireRate = client.hireRate;

  if (hireRate !== null && hireRate !== undefined) {
    if (hireRate === 0) {
      score -= 30;
      details.push('🚩 İşe alım oranı: %0 — Hiç işe almamış (-30)');
    } else if (hireRate < 30) {
      score -= 15;
      details.push(`📉 İşe alım oranı: %${hireRate} — Düşük (-15)`);
    } else if (hireRate >= 30 && hireRate <= 60) {
      // Nötr — puan değişmez
      details.push(`📊 İşe alım oranı: %${hireRate} — Ortalama (0)`);
    } else if (hireRate > 60 && hireRate <= 80) {
      score += 15;
      details.push(`✅ İşe alım oranı: %${hireRate} — İyi (+15)`);
    } else if (hireRate > 80) {
      score += 20;
      details.push(`🌟 İşe alım oranı: %${hireRate} — Çok İyi (+20)`);
    }
  } else {
    details.push('⚠️ İşe alım oranı bilgisi yok');
  }

  // ═══════════════════════════════════════════════════════════════
  // 4. MÜŞTERİ PUANI (-20 ile +20)
  // ═══════════════════════════════════════════════════════════════
  const rating = client.rating;

  if (rating !== null && rating !== undefined) {
    if (rating < 3.0) {
      score -= 20;
      details.push(`🚩 Müşteri puanı: ${rating}/5.0 — Düşük (-20)`);
    } else if (rating >= 3.0 && rating < 4.0) {
      score -= 5;
      details.push(`📉 Müşteri puanı: ${rating}/5.0 — Ortanın altı (-5)`);
    } else if (rating >= 4.0 && rating <= 4.5) {
      score += 10;
      details.push(`✅ Müşteri puanı: ${rating}/5.0 — İyi (+10)`);
    } else if (rating > 4.5) {
      score += 20;
      details.push(`🌟 Müşteri puanı: ${rating}/5.0 — Mükemmel (+20)`);
    }
  } else {
    score -= 10;
    details.push('⚠️ Müşteri puanı yok (-10)');
  }

  // ═══════════════════════════════════════════════════════════════
  // 5. DEĞERLENDİRME SAYISI (-10 ile +15)
  // ═══════════════════════════════════════════════════════════════
  const reviewCount = client.reviewCount;

  if (reviewCount !== null && reviewCount !== undefined) {
    if (reviewCount === 0) {
      score -= 10;
      details.push('📉 Değerlendirme sayısı: 0 — Hiç değerlendirilmemiş (-10)');
    } else if (reviewCount > 0 && reviewCount <= 5) {
      // Az ama var — nötr
      details.push(`📊 Değerlendirme sayısı: ${reviewCount} — Az (0)`);
    } else if (reviewCount > 5 && reviewCount <= 20) {
      score += 10;
      details.push(`✅ Değerlendirme sayısı: ${reviewCount} — İyi (+10)`);
    } else if (reviewCount > 20) {
      score += 15;
      details.push(`🌟 Değerlendirme sayısı: ${reviewCount} — Çok İyi (+15)`);
    }
  } else {
    details.push('⚠️ Değerlendirme sayısı bilgisi yok');
  }

  // ═══════════════════════════════════════════════════════════════
  // EK FAKTÖRLER
  // ═══════════════════════════════════════════════════════════════

  // Müşteri ülkesi (bilgi amaçlı, skora etki etmez)
  if (client.country) {
    details.push(`📍 Müşteri konumu: ${client.country}`);
  }

  // Üyelik süresi
  if (client.memberSince) {
    details.push(`📅 Üyelik tarihi: ${client.memberSince}`);
  }

  // İlan sayısı
  if (client.jobsPosted) {
    details.push(`📋 Toplam ilan: ${client.jobsPosted}`);
  }

  // ─── Skor sınırlandırma ──────────────────────────────────────
  score = Math.max(0, Math.min(100, score));

  return {
    score,
    label: scoreToLabel(score),
    details
  };
}


/**
 * Skoru etikete çevirir
 * @param {number} score
 * @returns {string}
 */
function scoreToLabel(score) {
  if (score <= 30) return 'Riskli Müşteri';
  if (score <= 60) return 'Dikkatli Olun';
  if (score <= 80) return 'Güvenilir';
  return 'Çok Güvenilir';
}


/**
 * Para miktarını okunabilir formata çevirir
 * @param {number} amount
 * @returns {string}
 */
function formatMoney(amount) {
  if (amount >= 1000000) return `${(amount / 1000000).toFixed(1)}M`;
  if (amount >= 1000) return `${(amount / 1000).toFixed(1)}K`;
  return amount.toLocaleString('en-US');
}
