/**
 * Budget Analysis Module — Bütçe Analizi
 * 
 * İş ilanının bütçesini pazar oranlarına, deneyim seviyesine
 * ve kullanıcının minimum beklentilerine göre puanlar.
 */

// ─── Pazar Oranları (saatlik, USD) ────────────────────────────────
const MARKET_RATES = {
  entry: { min: 10, max: 25, label: 'Giriş Seviye' },
  intermediate: { min: 25, max: 60, label: 'Orta Seviye' },
  expert: { min: 60, max: 150, label: 'Uzman Seviye' }
};

// ─── Sabit fiyat karmaşıklık tahmini (kelime sayısına göre) ───────
const COMPLEXITY_THRESHOLDS = {
  simple: { maxWords: 100, minBudget: 50 },
  moderate: { maxWords: 300, minBudget: 200 },
  complex: { maxWords: 600, minBudget: 500 },
  enterprise: { maxWords: Infinity, minBudget: 1000 }
};


/**
 * İş ilanının bütçesini analiz eder
 * 
 * @param {object} jobData - İçerik scriptinden gelen iş verisi
 * @param {object} userProfile - Kullanıcı profili (minimum oranlar vb.)
 * @returns {{ score: number, label: string, details: string[] }}
 */
export function analyzeBudget(jobData, userProfile) {
  const details = [];
  let score = 50; // Nötr başlangıç

  const budget = jobData.budget;
  const level = jobData.experienceLevel;
  const description = jobData.description || '';
  const wordCount = description.trim().split(/\s+/).filter(Boolean).length;

  // ─── Bütçe bilgisi yoksa ─────────────────────────────────────
  if (!budget || (!budget.type && !budget.amount && !budget.min && !budget.max)) {
    details.push('⚠️ Bütçe bilgisi belirtilmemiş');
    return {
      score: 40,
      label: scoreToLabel(40),
      details
    };
  }

  // ═══════════════════════════════════════════════════════════════
  // SAATLİK BÜTÇE ANALİZİ
  // ═══════════════════════════════════════════════════════════════
  if (budget.type === 'hourly') {
    const hourlyMin = budget.min || 0;
    const hourlyMax = budget.max || hourlyMin;
    const avgRate = hourlyMin && hourlyMax ? (hourlyMin + hourlyMax) / 2 : hourlyMin || hourlyMax;

    details.push(`💰 Saatlik bütçe: $${hourlyMin} – $${hourlyMax}`);

    // Kullanıcının minimum saatlik ücretiyle karşılaştır
    const userMinRate = userProfile?.minimumHourlyRate || 25;

    if (hourlyMax > 0 && hourlyMax < userMinRate) {
      const diff = userMinRate - hourlyMax;
      score -= Math.min(25, Math.round(diff * 1.5));
      details.push(`📉 Maksimum ücret ($${hourlyMax}), minimum beklentinizin ($${userMinRate}) altında`);
    } else if (hourlyMin >= userMinRate) {
      score += 15;
      details.push(`✅ Minimum ücret ($${hourlyMin}), beklentinizi ($${userMinRate}) karşılıyor`);
    }

    // Pazar oranlarıyla karşılaştır
    if (level && MARKET_RATES[level]) {
      const marketRate = MARKET_RATES[level];
      details.push(`📊 ${marketRate.label} pazar oranı: $${marketRate.min} – $${marketRate.max}/saat`);

      if (avgRate > 0) {
        if (avgRate < marketRate.min) {
          // Pazar ortalamasının altında
          const ratio = avgRate / marketRate.min;
          const penalty = Math.round((1 - ratio) * 30);
          score -= penalty;
          details.push(`⚠️ Bütçe pazar oranının altında (${Math.round(ratio * 100)}%)`);
        } else if (avgRate >= marketRate.min && avgRate <= marketRate.max) {
          score += 10;
          details.push('✅ Bütçe pazar oranı aralığında');
        } else if (avgRate > marketRate.max) {
          score += 20;
          details.push('🌟 Bütçe pazar ortalamasının üzerinde');
        }
      }
    }

    // Deneyim / bütçe uyumsuzluğu
    if (level === 'expert' && avgRate < 30) {
      score -= 15;
      details.push('🚩 Uzman seviyesi isteniyor ama bütçe çok düşük');
    } else if (level === 'entry' && avgRate > 50) {
      score += 10;
      details.push('🌟 Giriş seviyesi için cömert bütçe');
    }

    // $0 saatlik ücret uyarısı
    if (hourlyMax === 0 && hourlyMin === 0) {
      score -= 20;
      details.push('🚩 Saatlik ücret $0 olarak belirtilmiş');
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // SABİT FİYAT BÜTÇE ANALİZİ
  // ═══════════════════════════════════════════════════════════════
  else if (budget.type === 'fixed') {
    const amount = budget.amount || 0;
    details.push(`💰 Sabit bütçe: $${amount}`);

    // Kullanıcının minimum sabit bütçesiyle karşılaştır
    const userMinFixed = userProfile?.minimumFixedBudget || 100;

    if (amount > 0 && amount < userMinFixed) {
      score -= 15;
      details.push(`📉 Bütçe ($${amount}), minimum beklentinizin ($${userMinFixed}) altında`);
    } else if (amount >= userMinFixed) {
      score += 10;
      details.push(`✅ Bütçe ($${amount}), minimum beklentinizi ($${userMinFixed}) karşılıyor`);
    }

    // Açıklama karmaşıklığına göre bütçe uygunluğu
    const complexity = estimateComplexity(wordCount);
    const minExpected = complexity.minBudget;

    if (amount > 0 && amount < minExpected) {
      score -= 10;
      details.push(`⚠️ Projenin karmaşıklığına göre bütçe düşük (beklenen min: $${minExpected})`);
    } else if (amount >= minExpected * 2) {
      score += 10;
      details.push('✅ Bütçe, projenin karmaşıklığına uygun');
    }

    // Deneyim / bütçe uyumsuzluğu (sabit fiyat)
    if (level === 'expert' && amount < 200) {
      score -= 15;
      details.push('🚩 Uzman seviyesi isteniyor ama sabit bütçe çok düşük');
    }

    // $0 veya çok düşük sabit bütçe
    if (amount === 0) {
      score -= 20;
      details.push('🚩 Bütçe $0 olarak belirtilmiş');
    } else if (amount < 25) {
      score -= 15;
      details.push('⚠️ Bütçe çok düşük ($25 altı)');
    }

    // Yüksek bütçe bonusu
    if (amount >= 5000) {
      score += 10;
      details.push('🌟 Yüksek bütçeli proje ($5,000+)');
    } else if (amount >= 1000) {
      score += 5;
      details.push('👍 Orta-üst bütçeli proje ($1,000+)');
    }
  }

  // ─── Skor sınırlandırma ──────────────────────────────────────
  score = Math.max(0, Math.min(100, score));

  return {
    score,
    label: scoreToLabel(score),
    details
  };
}


/**
 * Kelime sayısına göre proje karmaşıklığını tahmin eder
 * @param {number} wordCount
 * @returns {{ minBudget: number }}
 */
function estimateComplexity(wordCount) {
  if (wordCount <= COMPLEXITY_THRESHOLDS.simple.maxWords) {
    return COMPLEXITY_THRESHOLDS.simple;
  }
  if (wordCount <= COMPLEXITY_THRESHOLDS.moderate.maxWords) {
    return COMPLEXITY_THRESHOLDS.moderate;
  }
  if (wordCount <= COMPLEXITY_THRESHOLDS.complex.maxWords) {
    return COMPLEXITY_THRESHOLDS.complex;
  }
  return COMPLEXITY_THRESHOLDS.enterprise;
}


/**
 * Skoru etikete çevirir
 * @param {number} score
 * @returns {string}
 */
function scoreToLabel(score) {
  if (score <= 30) return 'Düşük Bütçe';
  if (score <= 60) return 'Dikkatli Olun';
  if (score <= 80) return 'Uygun';
  return 'İyi Bütçe';
}
