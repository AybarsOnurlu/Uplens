import { StorageHelper, STORAGE_KEYS } from '../utils/storage.js';

let currentTheme = 'auto';
let currentSettings = null;

document.addEventListener('DOMContentLoaded', async () => {
  initTabs();
  await initTheme();
  await loadSettings();
  await loadAnalysis();
  await loadHistory();
  initSettingsEvents();
  listenForStorageChanges();
});

function initTabs() {
  const tabs = document.querySelectorAll('.tab-btn');
  const indicator = document.getElementById('tab-indicator');
  
  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => {
      // Update active class
      tabs.forEach(t => t.classList.remove('active', 'text-green-400'));
      tab.classList.add('active', 'text-green-400');
      
      // Move indicator
      indicator.style.left = `${index * 33.33}%`;
      
      // Show panel
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.add('hidden'));
      document.getElementById(tab.dataset.tab).classList.remove('hidden');
    });
  });
}

async function initTheme() {
  const profile = await StorageHelper.getUserProfile();
  setTheme(profile.theme || 'auto');
  
  document.getElementById('theme-toggle').addEventListener('click', () => {
    const nextTheme = currentTheme === 'dark' ? 'light' : 'dark';
    setTheme(nextTheme);
    StorageHelper.saveUserProfile({ ...currentSettings, theme: nextTheme });
  });
}

function setTheme(theme) {
  currentTheme = theme;
  const isDark = theme === 'dark' || (theme === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches);
  
  document.body.classList.toggle('dark', isDark);
  document.body.classList.toggle('bg-slate-900', isDark);
  document.body.classList.toggle('text-slate-200', isDark);
  document.body.classList.toggle('bg-slate-50', !isDark);
  document.body.classList.toggle('text-slate-800', !isDark);
  
  document.getElementById('theme-icon-dark').classList.toggle('hidden', !isDark);
  document.getElementById('theme-icon-light').classList.toggle('hidden', isDark);
  
  document.querySelectorAll('.theme-option').forEach(btn => {
    if (btn.dataset.theme === theme) {
      btn.classList.add('border-green-500', 'bg-green-500/10');
    } else {
      btn.classList.remove('border-green-500', 'bg-green-500/10');
    }
  });
}

async function loadAnalysis() {
  const analysis = await StorageHelper.getLastAnalysis();
  if (analysis) {
    renderAnalysis(analysis);
  } else {
    document.getElementById('empty-state').classList.remove('hidden');
    document.getElementById('analysis-content').classList.add('hidden');
  }
}

function renderAnalysis(data) {
  document.getElementById('empty-state').classList.add('hidden');
  const content = document.getElementById('analysis-content');
  content.classList.remove('hidden');
  
  // Header
  document.getElementById('job-title').textContent = data.jobTitle;
  document.getElementById('job-link').href = data.jobUrl;
  
  // Score
  document.getElementById('score-value').textContent = data.overallScore;
  document.getElementById('score-label').textContent = getScoreLabel(data.scoreLabel);
  document.getElementById('score-label').className = `mt-2 px-3 py-1 rounded-full text-xs font-semibold ${getScoreLabelClass(data.scoreLabel)}`;
  
  animateScore(data.overallScore);
  
  // Flags
  renderRedFlags(data.redFlags);
  renderGreenFlags(data.greenFlags);
  
  // Details
  renderBudgetAnalysis(data.budgetAnalysis);
  renderClientAnalysis(data.clientAnalysis);
  renderSkillMatch(data.skillMatch);
}

function animateScore(score) {
  const ring = document.getElementById('score-ring');
  const circumference = 326.73; // 2 * PI * 52
  const offset = circumference - (score / 100) * circumference;
  
  // Trigger reflow to restart animation
  ring.style.strokeDashoffset = circumference;
  ring.getBoundingClientRect(); 
  ring.style.strokeDashoffset = offset;
  
  // Set color based on score
  let color = '#14a800'; // good
  if (score <= 30) color = '#ef4444'; // high-risk
  else if (score <= 60) color = '#f59e0b'; // caution
  else if (score <= 80) color = '#22c55e'; // decent
  
  ring.style.stroke = color;
  document.getElementById('score-value').style.color = color;
}

function renderRedFlags(flags) {
  const section = document.getElementById('redflags-section');
  if (!flags || flags.length === 0) {
    section.classList.add('hidden');
    return;
  }
  
  section.classList.remove('hidden');
  document.getElementById('redflags-count').textContent = flags.length;
  
  const list = document.getElementById('redflags-list');
  list.innerHTML = flags.map(flag => `
    <div class="flex items-start gap-2 p-2 rounded bg-slate-800/50 border border-slate-700">
      <span class="text-xs mt-0.5">${getSeverityIcon(flag.severity)}</span>
      <div>
        <div class="text-xs font-medium text-slate-200">${flag.reason}</div>
        ${flag.matchedText ? `<div class="text-[10px] text-slate-500 mt-1 italic">"${flag.matchedText}"</div>` : ''}
      </div>
    </div>
  `).join('');
}

function renderGreenFlags(flags) {
  const section = document.getElementById('greenflags-section');
  if (!flags || flags.length === 0) {
    section.classList.add('hidden');
    return;
  }
  
  section.classList.remove('hidden');
  const list = document.getElementById('greenflags-list');
  list.innerHTML = flags.map(flag => `
    <div class="flex items-center gap-1.5 text-xs text-slate-300">
      <span class="text-green-500">✓</span> ${flag.reason}
    </div>
  `).join('');
}

function renderBudgetAnalysis(data) {
  document.getElementById('budget-score').textContent = data.score + '/100';
  document.getElementById('budget-label').textContent = data.label;
  document.getElementById('budget-details').innerHTML = data.details.map(d => `<div>${d}</div>`).join('');
}

function renderClientAnalysis(data) {
  document.getElementById('client-score').textContent = data.score + '/100';
  document.getElementById('client-label').textContent = data.label;
  document.getElementById('client-details').innerHTML = data.details.map(d => `<div>${d}</div>`).join('');
}

function renderSkillMatch(data) {
  if (!data || data.matchPercentage === 0 && data.unmatched.length === 0 && data.matched.length === 0) {
    document.getElementById('no-skills-msg').classList.remove('hidden');
    document.getElementById('skill-tags').innerHTML = '';
    return;
  }
  
  document.getElementById('no-skills-msg').classList.add('hidden');
  document.getElementById('skill-percentage').textContent = `%${data.matchPercentage} Uyum`;
  document.getElementById('skill-bar').style.width = `${data.matchPercentage}%`;
  
  const tagsContainer = document.getElementById('skill-tags');
  let html = '';
  
  data.matched.forEach(skill => {
    html += `<span class="px-2 py-1 text-[10px] font-medium rounded-md bg-green-500/20 text-green-400 border border-green-500/30">${skill} ✓</span>`;
  });
  
  data.unmatched.forEach(skill => {
    html += `<span class="px-2 py-1 text-[10px] rounded-md bg-slate-700 text-slate-400 border border-slate-600">${skill}</span>`;
  });
  
  tagsContainer.innerHTML = html;
}

async function loadHistory() {
  const history = await StorageHelper.getHistory();
  const list = document.getElementById('history-list');
  const empty = document.getElementById('history-empty');
  const clearBtn = document.getElementById('clear-history');
  
  if (!history || history.length === 0) {
    empty.classList.remove('hidden');
    list.innerHTML = '';
    clearBtn.classList.add('hidden');
    return;
  }
  
  empty.classList.add('hidden');
  clearBtn.classList.remove('hidden');
  
  list.innerHTML = history.map(item => {
    const time = new Date(item.analyzedAt).toLocaleDateString('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
    const colorClass = getScoreColorClass(item.overallScore);
    
    return `
      <a href="${item.jobUrl}" target="_blank" class="block p-3 rounded-xl bg-slate-800/40 border border-slate-700/50 hover:border-slate-600 transition-colors">
        <div class="flex items-start justify-between gap-3">
          <div class="flex-1 min-w-0">
            <h4 class="text-xs font-semibold text-slate-200 truncate">${item.jobTitle}</h4>
            <div class="text-[10px] text-slate-500 mt-1">${time}</div>
          </div>
          <div class="flex-shrink-0 flex flex-col items-end">
            <span class="text-lg font-bold ${colorClass}">${item.overallScore}</span>
            <span class="text-[10px] font-medium px-1.5 py-0.5 rounded-sm bg-slate-800">${getScoreLabel(item.scoreLabel)}</span>
          </div>
        </div>
      </a>
    `;
  }).join('');
  
  clearBtn.onclick = async () => {
    await StorageHelper.clearHistory();
    loadHistory();
  };
}

async function loadSettings() {
  currentSettings = await StorageHelper.getUserProfile();
  
  document.getElementById('min-hourly').value = currentSettings.minimumHourlyRate || 25;
  document.getElementById('min-fixed').value = currentSettings.minimumFixedBudget || 100;
  
  // Render skill tags
  const container = document.getElementById('skills-input-container');
  const input = document.getElementById('skill-input');
  
  // Remove existing tags
  container.querySelectorAll('.skill-tag-chip').forEach(el => el.remove());
  
  // Add chips before input
  (currentSettings.skills || []).forEach(skill => {
    addSkillChip(skill, container, input);
  });
}

function addSkillChip(skill, container, inputEl) {
  const chip = document.createElement('div');
  chip.className = 'skill-tag-chip flex items-center gap-1 px-2 py-1 bg-slate-700 rounded text-xs text-slate-200';
  chip.innerHTML = `
    <span>${skill}</span>
    <button class="hover:text-red-400 focus:outline-none">&times;</button>
  `;
  chip.dataset.skill = skill;
  
  chip.querySelector('button').onclick = () => chip.remove();
  container.insertBefore(chip, inputEl);
}

function initSettingsEvents() {
  const container = document.getElementById('skills-input-container');
  const input = document.getElementById('skill-input');
  
  container.onclick = () => input.focus();
  
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      const val = input.value.trim().replace(/,/g, '');
      if (val) {
        addSkillChip(val, container, input);
        input.value = '';
      }
    } else if (e.key === 'Backspace' && input.value === '') {
      const chips = container.querySelectorAll('.skill-tag-chip');
      if (chips.length > 0) {
        chips[chips.length - 1].remove();
      }
    }
  });
  
  document.querySelectorAll('.theme-option').forEach(btn => {
    btn.onclick = () => {
      setTheme(btn.dataset.theme);
    };
  });
  
  document.getElementById('save-settings').onclick = async () => {
    const skills = Array.from(document.querySelectorAll('.skill-tag-chip')).map(el => el.dataset.skill);
    const minHourly = parseFloat(document.getElementById('min-hourly').value) || 0;
    const minFixed = parseFloat(document.getElementById('min-fixed').value) || 0;
    
    currentSettings = {
      ...currentSettings,
      skills,
      minimumHourlyRate: minHourly,
      minimumFixedBudget: minFixed,
      theme: currentTheme
    };
    
    await StorageHelper.saveUserProfile(currentSettings);
    
    // Show toast
    const toast = document.getElementById('save-toast');
    toast.classList.remove('hidden');
    setTimeout(() => toast.classList.add('hidden'), 3000);
    
    // Re-evaluate current analysis if exists
    const lastAnalysis = await StorageHelper.getLastAnalysis();
    if (lastAnalysis) {
      chrome.runtime.sendMessage({ type: 'ANALYZE_JOB', data: lastAnalysis.rawData });
    }
  };
}

function listenForStorageChanges() {
  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local' && changes[STORAGE_KEYS.HISTORY]) {
      loadHistory();
      // If history was updated, top item is the latest analysis
      const history = changes[STORAGE_KEYS.HISTORY].newValue;
      if (history && history.length > 0) {
        renderAnalysis(history[0]);
      } else {
        // History cleared
        document.getElementById('empty-state').classList.remove('hidden');
        document.getElementById('analysis-content').classList.add('hidden');
      }
    }
  });
}

// Helpers
function getScoreLabel(label) {
  const map = { 'high-risk': 'Yüksek Risk', 'caution': 'Dikkat', 'decent': 'Uygun', 'good': 'İyi Fırsat' };
  return map[label] || label;
}

function getScoreLabelClass(label) {
  const map = {
    'high-risk': 'bg-red-500/20 text-red-400',
    'caution': 'bg-amber-500/20 text-amber-400',
    'decent': 'bg-green-500/20 text-green-400',
    'good': 'bg-emerald-500/20 text-emerald-400'
  };
  return map[label] || 'bg-slate-500/20 text-slate-400';
}

function getScoreColorClass(score) {
  if (score <= 30) return 'text-red-500';
  if (score <= 60) return 'text-amber-500';
  if (score <= 80) return 'text-green-500';
  return 'text-emerald-500';
}

function getSeverityIcon(severity) {
  const map = { critical: '⛔', high: '🔴', medium: '🟠', low: '🟡' };
  return map[severity] || '⚠️';
}
