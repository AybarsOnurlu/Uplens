import { analyzeJob } from './analysis/scorer.js';
import { StorageHelper, DEFAULT_PROFILE } from './utils/storage.js';
import { MSG } from './utils/messaging.js';

// === Event listeners MUST be at top level ===

chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    await StorageHelper.saveUserProfile(DEFAULT_PROFILE);
    console.log('[UJA] Extension installed, default settings saved.');
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender).then(sendResponse).catch(err => {
    console.error('[UJA] Message handler error:', err);
    sendResponse({ error: err.message });
  });
  return true; // Keep channel open for async response
});

async function handleMessage(message, sender) {
  const { type, data } = message;
  
  switch (type) {
    case MSG.ANALYZE_JOB: {
      const profile = await StorageHelper.getUserProfile();
      const result = analyzeJob(data, profile);
      await StorageHelper.saveAnalysis(result);
      updateBadge(result.overallScore, sender.tab?.id);
      return { success: true, analysis: result };
    }
    case MSG.GET_ANALYSIS:
      return { success: true, analysis: await StorageHelper.getLastAnalysis() };
    case MSG.GET_HISTORY:
      return { success: true, history: await StorageHelper.getHistory() };
    case MSG.CLEAR_HISTORY:
      await StorageHelper.clearHistory();
      return { success: true };
    case MSG.GET_SETTINGS:
      return { success: true, profile: await StorageHelper.getUserProfile() };
    case MSG.UPDATE_SETTINGS:
      await StorageHelper.saveUserProfile(data);
      return { success: true };
    default:
      return { error: 'Unknown message type: ' + type };
  }
}

function updateBadge(score, tabId) {
  const text = String(score);
  let color;
  if (score <= 30) color = '#ef4444'; // red
  else if (score <= 60) color = '#f59e0b'; // amber
  else if (score <= 80) color = '#22c55e'; // green
  else color = '#14a800'; // upwork green
  
  const target = tabId ? { tabId } : {};
  chrome.action.setBadgeText({ text, ...target });
  chrome.action.setBadgeBackgroundColor({ color, ...target });
  chrome.action.setBadgeTextColor({ color: '#ffffff', ...target });
}
