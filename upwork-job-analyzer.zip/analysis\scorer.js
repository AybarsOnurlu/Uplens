/**
 * Job Scorer Module — Ana Puanlama Motoru
 * 
 * Tüm analiz alt modüllerini birleştirir ve ağırlıklı
 * genel skor hesaplar. Yetenek eşleştirmesi de burada yapılır.
 * 
 * Ağırlıklar:
 * - Bütçe: %25
 * - Müşteri: %30
 * - Kalite: %25
 * - Risk: %20
 */

import { detectRedFlags, SEVERITY_WEIGHTS } from './redflags.js';
import { analyzeBudget } from './budget.js';
import { analyzeClient } from './client.js';


// ─── Ağırlık Sabitleri ─────────────────────────────────────────────
const WEIGHTS = {
  BUDGET: 0.25,
  CLIENT: 0.30,
  QUALITY: 0.25,
  RISK: 0.20
};


/**
 * İş ilanını tam kapsamlı analiz eder
 * 
 * @param {object} jobData - İçerik scriptinden gelen iş verisi
 * @param {object} userProfile - Kullanıcı profili (yetenekler, minimum oranlar)
 * @returns {object} Tam analiz sonucu (analysisResult formatında)
 */
export function analyzeJob(jobData, userProfile) {
  // ─── Alt analizleri çalıştır ─────────────────────────────────
  const { redFlags, greenFlags } = detectRedFlags(jobData);
  const budgetAnalysis = analyzeBudget(jobData, userProfile);
  const clientAnalysis = analyzeClient(jobData);
  const qualityAnalysis = analyzeQuality(jobData);
  const riskScore = calculateRiskScore(redFlags);
  const skillMatch = matchSkills(jobData.skills, userProfile?.skills);

  // ─── Ağırlıklı genel skor ───────────────────────────────────
  const overallScore = Math.round(
    budgetAnalysis.score * WEIGHTS.BUDGET +
    clientAnalysis.score * WEIGHTS.CLIENT +
    qualityAnalysis.score * WEIGHTS.QUALITY +
    riskScore * WEIGHTS.RISK
  );

  // Skor sınırlandırma
  const clampedScore = Math.max(0, Math.min(100, overallScore));

  // ─── Kritik kırmızı bayrak varsa skoru düşür ────────────────
  const criticalFlags = redFlags.filter(f => f.severity === 'critical');
  let finalScore = clampedScore;

  if (criticalFlags.length > 0) {
    // Her kritik bayrak skoru %15 düşürür (minimum 5)
    const criticalPenalty = criticalFlags.length * 15;
    finalScore = Math.max(5, finalScore - criticalPenalty);
  }

  finalScore = Math.max(0, Math.min(100, finalScore));

  // ─── Sonuç objesi oluştur ───────────────────────────────────
  const analysisResult = {
    jobId: jobData.id || '',
    jobTitle: jobData.title || '',
    jobUrl: jobData.url || '',
    overallScore: finalScore,
    scoreLabel: getScoreLabel(finalScore),
    budgetAnalysis: {
      score: budgetAnalysis.score,
      label: budgetAnalysis.label,
      details: budgetAnalysis.details
    },
    clientAnalysis: {
      score: clientAnalysis.score,
      label: clientAnalysis.label,
      details: clientAnalysis.details
    },
    qualityAnalysis: {
      score: qualityAnalysis.score,
      label: qualityAnalysis.label,
      details: qualityAnalysis.details
    },
    redFlags,
    greenFlags,
    skillMatch,
    rawData: jobData,
    analyzedAt: Date.now()
  };

  return analysisResult;
}


/**
 * İlan kalitesini analiz eder (açıklama uzunluğu, yetenek, deneyim eşleşmesi)
 * 
 * @param {object} jobData
 * @returns {{ score: number, label: string, details: string[] }}
 */
function analyzeQuality(jobData) {
  const details = [];
  let score = 50;

  const description = jobData.description || '';
  const wordCount = description.trim().split(/\s+/).filter(Boolean).length;

  // ─── Açıklama uzunluğu ───────────────────────────────────────
  if (wordCount === 0) {
    score -= 30;
    details.push('🚩 İlan açıklaması boş');
  } else if (wordCount < 30) {
    score -= 20;
    details.push(`📉 Çok kısa açıklama: ${wordCount} kelime`);
  } else if (wordCount < 50) {
    score -= 10;
    details.push(`⚠️ Kısa açıklama: ${wordCount} kelime`);
  } else if (wordCount >= 50 && wordCount < 150) {
    score += 5;
    details.push(`📊 Orta uzunlukta açıklama: ${wordCount} kelime`);
  } else if (wordCount >= 150 && wordCount < 300) {
    score += 15;
    details.push(`✅ Detaylı açıklama: ${wordCount} kelime`);
  } else if (wordCount >= 300) {
    score += 20;
    details.push(`🌟 Çok detaylı açıklama: ${wordCount} kelime`);
  }

  // ─── Yetenek etiketleri ──────────────────────────────────────
  const skills = jobData.skills || [];

  if (skills.length === 0) {
    score -= 10;
    details.push('⚠️ Yetenek etiketi belirtilmemiş');
  } else if (skills.length >= 1 && skills.length <= 5) {
    score += 10;
    details.push(`✅ ${skills.length} yetenek belirtilmiş — Odaklı ilan`);
  } else if (skills.length > 5 && skills.length <= 10) {
    score += 5;
    details.push(`📊 ${skills.length} yetenek belirtilmiş`);
  } else if (skills.length > 10) {
    score -= 5;
    details.push(`⚠️ ${skills.length} yetenek belirtilmiş — Aşırı geniş beklenti`);
  }

  // ─── Deneyim seviyesi ────────────────────────────────────────
  if (jobData.experienceLevel) {
    const levelLabels = {
      entry: 'Giriş Seviye',
      intermediate: 'Orta Seviye',
      expert: 'Uzman'
    };
    details.push(`📋 Deneyim seviyesi: ${levelLabels[jobData.experienceLevel] || jobData.experienceLevel}`);
    score += 5; // Deneyim seviyesi belirtilmesi olumlu
  } else {
    details.push('⚠️ Deneyim seviyesi belirtilmemiş');
  }

  // ─── Proje süresi ────────────────────────────────────────────
  if (jobData.projectLength) {
    details.push(`⏱️ Proje süresi: ${jobData.projectLength}`);
    score += 3;
  }

  // ─── Haftalık saat ────────────────────────────────────────────
  if (jobData.weeklyHours) {
    details.push(`🕐 Haftalık saat: ${jobData.weeklyHours}`);
    score += 2;
  }

  // ─── Kategori ────────────────────────────────────────────────
  if (jobData.category) {
    details.push(`📂 Kategori: ${jobData.category}`);
  }

  // ─── Teklif sayısı ───────────────────────────────────────────
  if (jobData.proposalCount !== null && jobData.proposalCount !== undefined) {
    if (jobData.proposalCount < 5) {
      score += 10;
      details.push(`🌟 Az teklif: ${jobData.proposalCount} — Düşük rekabet`);
    } else if (jobData.proposalCount >= 5 && jobData.proposalCount <= 15) {
      score += 5;
      details.push(`📊 Normal teklif sayısı: ${jobData.proposalCount}`);
    } else if (jobData.proposalCount > 15 && jobData.proposalCount <= 50) {
      details.push(`⚠️ Yüksek teklif sayısı: ${jobData.proposalCount}`);
    } else if (jobData.proposalCount > 50) {
      score -= 10;
      details.push(`🚩 Çok yüksek rekabet: ${jobData.proposalCount}+ teklif`);
    }
  }

  // ─── Skor sınırlandırma ──────────────────────────────────────
  score = Math.max(0, Math.min(100, score));

  return {
    score,
    label: qualityLabel(score),
    details
  };
}


/**
 * Kırmızı bayrakların ağırlığına göre risk skoru hesaplar
 * Yüksek skor = düşük risk (iyi)
 * 
 * @param {object[]} redFlags
 * @returns {number} 0-100 risk skoru (100 = risksiz)
 */
function calculateRiskScore(redFlags) {
  if (redFlags.length === 0) return 100;

  // Toplam risk puanını hesapla
  let totalPenalty = 0;
  for (const flag of redFlags) {
    totalPenalty += SEVERITY_WEIGHTS[flag.severity] || 5;
  }

  // Maksimum ceza sınırı
  const maxPenalty = 100;
  const normalizedPenalty = Math.min(totalPenalty, maxPenalty);

  // 100'den çıkar (yüksek skor = düşük risk)
  return Math.max(0, 100 - normalizedPenalty);
}


/**
 * Kullanıcı yetenekleri ile ilan yeteneklerini eşleştirir
 * 
 * @param {string[]} jobSkills - İlandaki yetenekler
 * @param {string[]} userSkills - Kullanıcının yetenekleri
 * @returns {{ matched: string[], unmatched: string[], matchPercentage: number }}
 */
function matchSkills(jobSkills = [], userSkills = []) {
  if (!jobSkills.length || !userSkills.length) {
    return {
      matched: [],
      unmatched: jobSkills || [],
      matchPercentage: 0
    };
  }

  // Case-insensitive karşılaştırma
  const normalizedUserSkills = userSkills.map(s => s.toLowerCase().trim());

  const matched = [];
  const unmatched = [];

  for (const skill of jobSkills) {
    const normalizedSkill = skill.toLowerCase().trim();

    // Tam eşleşme veya kısmi eşleşme (includes)
    const isMatch = normalizedUserSkills.some(
      userSkill =>
        userSkill === normalizedSkill ||
        normalizedSkill.includes(userSkill) ||
        userSkill.includes(normalizedSkill)
    );

    if (isMatch) {
      matched.push(skill);
    } else {
      unmatched.push(skill);
    }
  }

  const matchPercentage = jobSkills.length > 0
    ? Math.round((matched.length / jobSkills.length) * 100)
    : 0;

  return {
    matched,
    unmatched,
    matchPercentage
  };
}


/**
 * Genel skoru etikete çevirir
 * @param {number} score
 * @returns {'high-risk' | 'caution' | 'decent' | 'good'}
 */
function getScoreLabel(score) {
  if (score <= 30) return 'high-risk';
  if (score <= 60) return 'caution';
  if (score <= 80) return 'decent';
  return 'good';
}


/**
 * Kalite skorunu etikete çevirir
 * @param {number} score
 * @returns {string}
 */
function qualityLabel(score) {
  if (score <= 30) return 'Düşük Kalite';
  if (score <= 60) return 'Orta Kalite';
  if (score <= 80) return 'İyi Kalite';
  return 'Yüksek Kalite';
}
