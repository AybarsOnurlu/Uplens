const UJA_CONSTANTS = {
  MSG: {
    ANALYZE_JOB: 'ANALYZE_JOB',
    JOB_ANALYZED: 'JOB_ANALYZED'
  },
  DEBOUNCE_MS: 1500
};

let lastExtractedUrl = '';
let extractTimeout = null;

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

function init() {
  console.log('[UJA] Content script initialized on', window.location.href);
  setupMutationObserver();
  scheduleExtraction();
}

// Watch for SPA navigation and dynamic DOM changes
function setupMutationObserver() {
  const observer = new MutationObserver((mutations) => {
    // Check if URL changed
    if (window.location.href !== lastExtractedUrl) {
      scheduleExtraction();
      return;
    }

    // Check if new meaningful content was added
    for (const mutation of mutations) {
      if (mutation.addedNodes.length > 0) {
        // Quick check if job-related elements might have been added
        const hasRelevantAdditions = Array.from(mutation.addedNodes).some(node => {
          if (node.nodeType === 1) { // Element node
            return node.matches && (
              node.matches('[data-test="job-title"]') || 
              node.querySelector('[data-test="job-title"]') ||
              node.matches('.job-tile') ||
              node.querySelector('.job-tile')
            );
          }
          return false;
        });

        if (hasRelevantAdditions) {
          scheduleExtraction();
          break;
        }
      }
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

function scheduleExtraction() {
  if (extractTimeout) {
    clearTimeout(extractTimeout);
  }
  extractTimeout = setTimeout(extractAndAnalyze, UJA_CONSTANTS.DEBOUNCE_MS);
}

function extractAndAnalyze() {
  const url = window.location.href;
  lastExtractedUrl = url;

  if (url.includes('/jobs/~')) {
    extractJobDetailPage();
  } else if (url.includes('/nx/search/jobs/') || url.includes('/nx/find-work/') || url.includes('/ab/jobs/search/')) {
    // extractSearchResults(); // Implementation for search results omitted for brevity, focusing on detail page
    console.log('[UJA] Search results page detected, but list injection not yet fully implemented in this version.');
  }
}

// Extract data from a specific job detail page
function extractJobDetailPage() {
  console.log('[UJA] Extracting job details...');
  
  const jobData = {
    id: extractJobId(window.location.href),
    url: window.location.href,
    title: extractTitle(),
    description: extractDescription(),
    budget: extractBudget(),
    client: extractClientInfo(),
    skills: extractSkills(),
    experienceLevel: extractExperienceLevel(),
    projectLength: extractProjectLength(),
    proposals: extractProposals(),
    extractedAt: Date.now()
  };

  console.log('[UJA] Extracted Job Data:', jobData);
  sendForAnalysis(jobData);
}

// --- Extraction Strategies ---

function extractJobId(url) {
  const match = url.match(/~([a-zA-Z0-9]+)/);
  return match ? match[0] : null;
}

function extractTitle() {
  const el = document.querySelector('[data-test="job-title"]') || 
             document.querySelector('h1') || 
             document.querySelector('h2');
  return el ? el.textContent.trim() : '';
}

function extractDescription() {
  const el = document.querySelector('[data-test="job-description"]') || 
             document.querySelector('[data-test="description"]') ||
             document.querySelector('.job-description');
  return el ? el.textContent.trim() : '';
}

function extractBudget() {
  const budget = { type: null, amount: null, min: null, max: null };
  const html = document.body.innerText;
  
  // Very simplistic text matching as fallback, usually Upwork uses specific DOM structures
  // E.g. Fixed-price $500
  if (html.includes('Fixed-price')) {
    budget.type = 'fixed';
    const match = html.match(/\$[\d,]+/);
    if (match) budget.amount = parseFloat(match[0].replace(/[\$,]/g, ''));
  } else if (html.includes('Hourly:')) {
    budget.type = 'hourly';
    // $15.00 - $30.00
    const match = html.match(/\$[\d.]+\s*-\s*\$[\d.]+/);
    if (match) {
      const parts = match[0].match(/[\d.]+/g);
      if (parts && parts.length === 2) {
        budget.min = parseFloat(parts[0]);
        budget.max = parseFloat(parts[1]);
      }
    }
  }
  return budget;
}

function extractClientInfo() {
  const client = {
    country: '',
    paymentVerified: false,
    rating: null,
    reviewCount: 0,
    totalSpent: '',
    totalSpentNumeric: 0,
    hireRate: null,
    memberSince: null
  };
  
  const text = document.body.innerText;
  if (text.includes('Payment method verified') || text.includes('Payment verified')) {
    client.paymentVerified = true;
  }
  
  // Total spent e.g. "$10K+ spent"
  const spentMatch = text.match(/\$[\dKkMm.]+\+?\s*spent/i);
  if (spentMatch) {
    client.totalSpent = spentMatch[0].split(' ')[0];
  }

  // Hire rate e.g. "80% hire rate"
  const hireMatch = text.match(/(\d+)%\s*hire rate/i);
  if (hireMatch) {
    client.hireRate = parseInt(hireMatch[1], 10);
  }
  
  // Rating e.g. "4.89 of 5 reviews"
  const ratingMatch = text.match(/([\d.]+)\s*of\s*5\s*reviews/i) || text.match(/([\d.]+)\s*stars/i);
  if (ratingMatch) {
    client.rating = parseFloat(ratingMatch[1]);
  }

  return client;
}

function extractSkills() {
  const skills = [];
  const skillEls = document.querySelectorAll('[data-test="skill"], a[href*="/freelance-jobs/"]');
  skillEls.forEach(el => {
    const text = el.textContent.trim();
    if (text && !skills.includes(text)) {
      skills.push(text);
    }
  });
  return skills;
}

function extractExperienceLevel() {
  const text = document.body.innerText;
  if (text.includes('Expert')) return 'expert';
  if (text.includes('Intermediate')) return 'intermediate';
  if (text.includes('Entry level')) return 'entry';
  return null;
}

function extractProjectLength() {
  const text = document.body.innerText;
  const match = text.match(/Less than \d+ months|More than \d+ months|\d+ to \d+ months/i);
  return match ? match[0] : null;
}

function extractProposals() {
  const text = document.body.innerText;
  const match = text.match(/Proposals:\s*([^\n]+)/i);
  return match ? match[1].trim() : null;
}

// --- Analysis & Overlay ---

function sendForAnalysis(jobData) {
  chrome.runtime.sendMessage({ type: UJA_CONSTANTS.MSG.ANALYZE_JOB, data: jobData }, (response) => {
    if (chrome.runtime.lastError) {
      console.warn('[UJA] Service worker not ready or error:', chrome.runtime.lastError.message);
      return;
    }
    if (response && response.success && response.analysis) {
      injectOverlay(response.analysis);
    }
  });
}

function injectOverlay(analysis) {
  let overlay = document.getElementById('uja-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'uja-overlay';
    overlay.className = 'uja-overlay uja-minimized';
    document.body.appendChild(overlay);
  }

  const { overallScore, scoreLabel, redFlags } = analysis;
  
  let color = '#14a800'; // good
  if (overallScore <= 30) color = '#ef4444'; // high-risk
  else if (overallScore <= 60) color = '#f59e0b'; // caution
  else if (overallScore <= 80) color = '#22c55e'; // decent

  const redFlagCount = redFlags ? redFlags.length : 0;
  
  overlay.innerHTML = `
    <div class="uja-overlay-inner" style="--score-color: ${color}">
      <div class="uja-score-ring-container">
        <svg class="uja-score-ring" viewBox="0 0 36 36">
          <path class="uja-score-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
          <path class="uja-score-path" stroke-dasharray="${overallScore}, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
        </svg>
        <div class="uja-score-value">${overallScore}</div>
      </div>
      <div class="uja-details">
        <div class="uja-label">${scoreLabel.toUpperCase()}</div>
        ${redFlagCount > 0 ? `<div class="uja-flags-badge">🚩 ${redFlagCount} Risk</div>` : '<div class="uja-flags-badge uja-safe">✅ Temiz</div>'}
      </div>
    </div>
  `;

  overlay.onclick = () => {
    // Attempt to open the popup (Chrome doesn't allow programmatic popup opening from content scripts easily, 
    // but we can toggle minimize state for now)
    overlay.classList.toggle('uja-minimized');
  };
}
