/**
 * Red Flag Detection Module — Kırmızı / Yeşil Bayrak Tespiti
 * 
 * İş ilanlarındaki risk göstergelerini ve olumlu sinyalleri tespit eder.
 * Her bayrak severity (önem), category (kategori) ve açıklama içerir.
 */

// ─── Severity Seviyeleri ───────────────────────────────────────────
const SEVERITY = {
  CRITICAL: 'critical',   // Kesinlikle kaçınılmalı
  HIGH: 'high',           // Yüksek risk
  MEDIUM: 'medium',       // Dikkat edilmeli
  LOW: 'low'              // Hafif uyarı
};

// ─── Severity → Sayısal Ağırlık (scorer.js'de kullanılır) ─────────
export const SEVERITY_WEIGHTS = {
  [SEVERITY.CRITICAL]: 25,
  [SEVERITY.HIGH]: 15,
  [SEVERITY.MEDIUM]: 8,
  [SEVERITY.LOW]: 3
};


/**
 * İş ilanındaki kırmızı bayrakları tespit eder
 * 
 * @param {object} jobData - İçerik scriptinden gelen iş verisi
 * @returns {{ redFlags: object[], greenFlags: object[] }}
 */
export function detectRedFlags(jobData) {
  const redFlags = [];
  const greenFlags = [];

  const description = (jobData.description || '').toLowerCase();
  const title = (jobData.title || '').toLowerCase();
  const fullText = `${title} ${description}`;
  const wordCount = (jobData.description || '').trim().split(/\s+/).filter(Boolean).length;

  let flagIdCounter = 0;
  const addRedFlag = (severity, titleText, desc, category) => {
    redFlags.push({
      id: `rf-${++flagIdCounter}`,
      severity,
      title: titleText,
      description: desc,
      category
    });
  };

  const addGreenFlag = (titleText, desc) => {
    greenFlags.push({ title: titleText, description: desc });
  };


  // ═══════════════════════════════════════════════════════════════
  // CRITICAL FLAGS — Kesinlikle kaçınılması gereken durumlar
  // ═══════════════════════════════════════════════════════════════

  // 1. Platform dışı iletişim istekleri
  const offPlatformPatterns = [
    /\b(telegram|whatsapp|whats\s*app)\b/i,
    /\b(skype|discord|signal)\b/i,
    /\b(contact\s+me\s+(at|on|via))\b/i,
    /\b(reach\s+(me|out)\s+(at|on|via))\b/i,
    /\b(email\s+me|send\s+(me\s+)?(an?\s+)?email)\b/i,
    /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/  // email adresi
  ];

  for (const pattern of offPlatformPatterns) {
    if (pattern.test(fullText)) {
      addRedFlag(
        SEVERITY.CRITICAL,
        'Platform Dışı İletişim Talebi',
        'İlan platform dışı iletişim kanallarına yönlendiriyor. Bu, Upwork kurallarına aykırıdır ve dolandırıcılık riski taşır.',
        'communication'
      );
      break; // Aynı kategoriden bir tane yeter
    }
  }

  // 2. Ön ödeme / para istekleri
  const paymentRequestPatterns = [
    /\b(upfront\s+(payment|fee|cost|deposit))\b/i,
    /\b(pay\s+(before|first|upfront))\b/i,
    /\b(deposit\s+required)\b/i,
    /\b(registration\s+fee)\b/i,
    /\b(buy\s+(the\s+)?(software|license|tool|equipment))\b/i,
    /\b(invest(ment)?\s+required)\b/i,
    /\b(purchase\s+required)\b/i
  ];

  for (const pattern of paymentRequestPatterns) {
    if (pattern.test(fullText)) {
      addRedFlag(
        SEVERITY.CRITICAL,
        'Ön Ödeme / Yatırım Talebi',
        'İlan freelancer\'dan ön ödeme veya yatırım talep ediyor. Bu klasik bir dolandırıcılık yöntemidir.',
        'payment'
      );
      break;
    }
  }

  // 3. Kişisel bilgi istekleri
  const personalInfoPatterns = [
    /\b(ssn|social\s+security)\b/i,
    /\b(bank\s+(account|details|information|routing))\b/i,
    /\b(credit\s+card\s+(number|info|details))\b/i,
    /\b(password|login\s+credentials)\b/i,
    /\b(passport\s+(number|copy|scan))\b/i,
    /\b(identity\s+(card|document|verification))\b/i,
    /\b(driver'?s?\s+licen[sc]e)\b/i
  ];

  for (const pattern of personalInfoPatterns) {
    if (pattern.test(fullText)) {
      addRedFlag(
        SEVERITY.CRITICAL,
        'Kişisel Bilgi Talebi',
        'İlan hassas kişisel bilgiler (SSN, banka hesabı, şifre vb.) talep ediyor. Bu bilgiler asla paylaşılmamalıdır.',
        'personal_info'
      );
      break;
    }
  }


  // ═══════════════════════════════════════════════════════════════
  // HIGH FLAGS — Yüksek risk göstergeleri
  // ═══════════════════════════════════════════════════════════════

  // 4. Şüpheli dış bağlantılar
  const suspiciousLinkPatterns = [
    /\b(bit\.ly|tinyurl|goo\.gl|t\.co|shorturl)\b/i,
    /\b(click\s+(here|this\s+link))\b/i,
    /\b(fill\s+(out|in)\s+(this|the)\s+form)\b/i,
    /\b(apply\s+(here|at|via|through)\s+(this|the)?\s*(link|form|website|url))\b/i
  ];

  for (const pattern of suspiciousLinkPatterns) {
    if (pattern.test(fullText)) {
      addRedFlag(
        SEVERITY.HIGH,
        'Şüpheli Dış Bağlantı',
        'İlanda kısaltılmış URL\'ler veya dış form/site yönlendirmeleri bulunuyor.',
        'links'
      );
      break;
    }
  }

  // 5. Ödeme yöntemi doğrulanmamış
  if (jobData.client && !jobData.client.paymentVerified) {
    addRedFlag(
      SEVERITY.HIGH,
      'Ödeme Yöntemi Doğrulanmamış',
      'Müşterinin ödeme yöntemi Upwork tarafından doğrulanmamış. Ödeme sorunları yaşanabilir.',
      'client'
    );
  }

  // 6. Düşük işe alım oranı
  if (jobData.client?.hireRate !== null && jobData.client?.hireRate !== undefined) {
    if (jobData.client.hireRate < 20 && jobData.client.hireRate > 0) {
      addRedFlag(
        SEVERITY.HIGH,
        'Çok Düşük İşe Alım Oranı',
        `Müşterinin işe alım oranı sadece %${jobData.client.hireRate}. İlan açıp işe almayan bir müşteri olabilir.`,
        'client'
      );
    }
  }

  // 7. Test projesi / bedava çalışma
  const freeWorkPatterns = [
    /\b(free\s+(sample|trial|test|work))\b/i,
    /\b(unpaid\s+(test|trial|sample|task))\b/i,
    /\b(test\s+project\s+(first|before))\b/i,
    /\b(do\s+(a|this)\s+test\s+(first|task))\b/i,
    /\b(prove\s+(yourself|your\s+skills))\b/i,
    /\b(work\s+for\s+free)\b/i,
    /\b(no\s+pay(ment)?\s+(for|until))\b/i
  ];

  for (const pattern of freeWorkPatterns) {
    if (pattern.test(fullText)) {
      addRedFlag(
        SEVERITY.HIGH,
        'Bedava Çalışma / Test Projesi',
        'İlan ücretsiz test çalışması veya deneme projesi talep ediyor. Profesyonel iş ilişkilerinde bu kabul edilemez.',
        'exploitation'
      );
      break;
    }
  }


  // ═══════════════════════════════════════════════════════════════
  // MEDIUM FLAGS — Dikkat edilmesi gereken durumlar
  // ═══════════════════════════════════════════════════════════════

  // 8. Toplam harcama $0
  if (jobData.client?.totalSpentNumeric === 0) {
    addRedFlag(
      SEVERITY.MEDIUM,
      'Müşteri Hiç Harcama Yapmamış',
      'Müşteri platformda hiç para harcamamış ($0). Yeni veya güvenilmez bir müşteri olabilir.',
      'client'
    );
  }

  // 9. Müşteri puanı yok
  if (jobData.client && (jobData.client.rating === null || jobData.client.rating === undefined)) {
    addRedFlag(
      SEVERITY.MEDIUM,
      'Müşteri Puanı Yok',
      'Müşterinin henüz bir değerlendirme puanı bulunmuyor. Geçmiş deneyimi hakkında bilgi yok.',
      'client'
    );
  }

  // 10. Çok kısa açıklama
  if (wordCount > 0 && wordCount < 50) {
    addRedFlag(
      SEVERITY.MEDIUM,
      'Çok Kısa İlan Açıklaması',
      `İlan açıklaması sadece ${wordCount} kelime. Detaylı açıklama olmadan projenin kapsamı belirsiz kalır.`,
      'quality'
    );
  }

  // 11. Gerçekçi olmayan aciliyet
  const urgencyPatterns = [
    /\bURGENT\b/,                       // Büyük harflerle URGENT
    /\bASAP\b/,                         // Büyük harflerle ASAP
    /\bIMMEDIATELY\b/,                  // Büyük harflerle IMMEDIATELY
    /!!!+/,                             // Çoklu ünlem
    /\b(need(ed)?\s+(right\s+)?now)\b/i,
    /\b(start\s+(immediately|today|right\s+now))\b/i
  ];

  for (const pattern of urgencyPatterns) {
    if (pattern.test(jobData.description || '') || pattern.test(jobData.title || '')) {
      addRedFlag(
        SEVERITY.MEDIUM,
        'Gerçekçi Olmayan Aciliyet',
        'İlan aşırı aciliyet vurgusu içeriyor. Bu, freelancer\'ı düşünmeden kabul ettirmek için kullanılan bir taktik olabilir.',
        'quality'
      );
      break;
    }
  }

  // 12. Bütçe / Deneyim uyumsuzluğu
  if (jobData.experienceLevel === 'expert' && jobData.budget) {
    const budget = jobData.budget;
    let isMismatch = false;

    if (budget.type === 'hourly' && budget.max && budget.max < 25) {
      isMismatch = true;
    } else if (budget.type === 'fixed' && budget.amount && budget.amount < 100) {
      isMismatch = true;
    }

    if (isMismatch) {
      addRedFlag(
        SEVERITY.MEDIUM,
        'Bütçe / Deneyim Uyumsuzluğu',
        'Expert seviye deneyim isteniyor ancak bütçe giriş seviyesi. Müşteri düşük bütçeyle yüksek kalite bekliyor olabilir.',
        'budget'
      );
    }
  }


  // ═══════════════════════════════════════════════════════════════
  // LOW FLAGS — Hafif uyarılar
  // ═══════════════════════════════════════════════════════════════

  // 13. Çok fazla teklif (50+)
  if (jobData.proposalCount !== null && jobData.proposalCount !== undefined && jobData.proposalCount >= 50) {
    addRedFlag(
      SEVERITY.LOW,
      'Yüksek Rekabet (50+ Teklif)',
      `Bu ilana ${jobData.proposalCount}+ teklif verilmiş. Rekabetin çok yüksek olduğu ilanlarda seçilme şansı düşer.`,
      'competition'
    );
  }

  // 14. Yetenek belirtilmemiş
  if (!jobData.skills || jobData.skills.length === 0) {
    addRedFlag(
      SEVERITY.LOW,
      'Yetenek Belirtilmemiş',
      'İlanda hiç yetenek/beceri etiketi belirtilmemiş. Müşteri ne istediğinden emin olmayabilir.',
      'quality'
    );
  }

  // 15. Çok fazla yetenek isteniyor (10+)
  if (jobData.skills && jobData.skills.length > 10) {
    addRedFlag(
      SEVERITY.LOW,
      'Çok Fazla Yetenek İsteniyor',
      `İlanda ${jobData.skills.length} farklı yetenek isteniyor. Bu kadar geniş bir yetenek beklentisi gerçekçi olmayabilir.`,
      'quality'
    );
  }


  // ═══════════════════════════════════════════════════════════════
  // GREEN FLAGS — Olumlu göstergeler
  // ═══════════════════════════════════════════════════════════════

  // Ödeme doğrulanmış
  if (jobData.client?.paymentVerified) {
    addGreenFlag(
      'Ödeme Doğrulanmış ✓',
      'Müşterinin ödeme yöntemi Upwork tarafından doğrulanmış.'
    );
  }

  // Yüksek işe alım oranı (>70%)
  if (jobData.client?.hireRate > 70) {
    addGreenFlag(
      'Yüksek İşe Alım Oranı',
      `Müşterinin işe alım oranı %${jobData.client.hireRate}. Açtığı ilanlarda genellikle birini işe alıyor.`
    );
  }

  // Yüksek toplam harcama (>$10K)
  if (jobData.client?.totalSpentNumeric > 10000) {
    addGreenFlag(
      'Yüksek Platform Harcaması',
      `Müşteri platformda toplam $${formatMoney(jobData.client.totalSpentNumeric)} harcamış. Deneyimli bir müşteri.`
    );
  }

  // İyi puan (>4.5)
  if (jobData.client?.rating > 4.5) {
    addGreenFlag(
      'Yüksek Müşteri Puanı',
      `Müşterinin ortalama puanı ${jobData.client.rating}/5.0. Freelancer'lardan olumlu değerlendirmeler almış.`
    );
  }

  // Detaylı açıklama (>200 kelime)
  if (wordCount > 200) {
    addGreenFlag(
      'Detaylı İlan Açıklaması',
      `İlan açıklaması ${wordCount} kelime. Detaylı açıklamalar projenin kapsamını daha net ortaya koyar.`
    );
  }

  // Makul bütçe kontrolü
  if (jobData.budget) {
    const budget = jobData.budget;
    let isReasonable = false;

    if (budget.type === 'hourly') {
      if (jobData.experienceLevel === 'entry' && budget.min >= 10) isReasonable = true;
      if (jobData.experienceLevel === 'intermediate' && budget.min >= 25) isReasonable = true;
      if (jobData.experienceLevel === 'expert' && budget.min >= 60) isReasonable = true;
      if (!jobData.experienceLevel && budget.min >= 15) isReasonable = true;
    } else if (budget.type === 'fixed' && budget.amount >= 500) {
      isReasonable = true;
    }

    if (isReasonable) {
      addGreenFlag(
        'Makul Bütçe',
        'İlan bütçesi, istenen deneyim seviyesi için makul bir aralıkta.'
      );
    }
  }

  return { redFlags, greenFlags };
}


/**
 * Para miktarını okunabilir formata çevirir
 * @param {number} amount
 * @returns {string}
 */
function formatMoney(amount) {
  if (amount >= 1000000) return `${(amount / 1000000).toFixed(1)}M`;
  if (amount >= 1000) return `${(amount / 1000).toFixed(1)}K`;
  return amount.toString();
}
